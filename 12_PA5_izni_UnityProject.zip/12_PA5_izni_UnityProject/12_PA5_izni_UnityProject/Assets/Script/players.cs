﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class players : MonoBehaviour
{
   public float speed;
   Rigidbody playerRigidbody;
    public Text txt_score;
    public float score = 0;
    public int nextLevel;

    // Start is called before the first frame update
    void Start()
    {
       playerRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal, 0, MoveVertical);
        playerRigidbody.AddForce(movement * speed * Time.deltaTime);

        if(score == 4)
        {
            SceneManager.LoadScene(nextLevel);
        }
       
    }
    public void OnTriggerEnter(Collider other)
    {
        if(other.tag == "coingrab")
        {
            score++;
            Destroy(other.gameObject);
            txt_score.text = "SCORE: " + score;
        }
        if (other.tag == "hazardhit")
        {
            SceneManager.LoadScene(1);
        }
    }   
}
